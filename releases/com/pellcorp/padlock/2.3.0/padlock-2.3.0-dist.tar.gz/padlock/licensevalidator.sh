#!/bin/sh

java -cp "lib/*" net.padlocksoftware.padlock.tools.LicenseValidator $@

